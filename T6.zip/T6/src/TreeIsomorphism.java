import java.util.ArrayList;
import java.util.Collections;

public class TreeIsomorphism {

    private final Graph graph;

    public TreeIsomorphism(Graph graph) {
        if (graph == null) {
            throw new IllegalArgumentException("graph nao pode ser nulo");
        }

        this.graph = graph;
    }

    public Graph getGraph() {
        return graph;
    }

    public boolean isTree() {

        if (graph.E() != graph.V() - 1) {
            return false;
        }

        boolean[] visited = new boolean[graph.V()];

        dfs(0, visited);

        for (int v = 0; v < graph.V(); v++) {
            if (!visited[v]) {
                return false;
            }
        }

        return true;
    }

    private void dfs(int v, boolean[] visited) {

        visited[v] = true;

        for (int w : graph.adj(v)) {
            if (!visited[w]) {
                dfs(w, visited);
            }
        }
    }

    public String getValidationMessage() {

        if (isTree()) {
            return "Entrada valida: representa uma arvore.";
        }

        return "Entrada invalida: nao e arvore.";
    }

    public int[] getCenters() {

        int n = graph.V();

        if (n == 1) {
            return new int[]{0};
        }

        int[] degree = new int[n];

        ArrayList<Integer> leaves = new ArrayList<>();

        for (int v = 0; v < n; v++) {

            for (int w : graph.adj(v)) {
                degree[v]++;
            }

            if (degree[v] <= 1) {
                leaves.add(v);
            }
        }

        int processed = leaves.size();

        while (processed < n) {

            ArrayList<Integer> newLeaves = new ArrayList<>();

            for (int leaf : leaves) {

                for (int neighbor : graph.adj(leaf)) {

                    degree[neighbor]--;

                    if (degree[neighbor] == 1) {
                        newLeaves.add(neighbor);
                    }
                }
            }

            processed += newLeaves.size();

            leaves = newLeaves;
        }

        int[] centers = new int[leaves.size()];

        for (int i = 0; i < leaves.size(); i++) {
            centers[i] = leaves.get(i);
        }

        return centers;
    }

    private String encode(int node, int parent) {

        ArrayList<String> labels = new ArrayList<>();

        for (int neighbor : graph.adj(node)) {

            if (neighbor != parent) {
                labels.add(encode(neighbor, node));
            }
        }

        Collections.sort(labels);

        StringBuilder code = new StringBuilder();

        code.append("(");

        for (String s : labels) {
            code.append(s);
        }

        code.append(")");

        return code.toString();
    }


    public String getCanonicalEncoding() {

        if (!isTree()) {
            return "entrada invalida";
        }

        int[] centers = getCenters();

        if (centers.length == 1) {
            return encode(centers[0], -1);
        }

        String left = encode(centers[0], centers[1]);

        String right = encode(centers[1], centers[0]);

        if (left.compareTo(right) > 0) {
            String temp = left;
            left = right;
            right = temp;
        }

        return "(" + left + right + ")";
    }

}