public class Main {

    public static void main(String[] args) {

        Graph tree1 = new Graph(new In("dados/iso-path4-a.txt"));

        Graph tree2 = new Graph(new In("dados/iso-path4-b.txt"));

        TreeIsomorphism t1 = new TreeIsomorphism(tree1);

        TreeIsomorphism t2 = new TreeIsomorphism(tree2);


        StdOut.println("ARVORE 1");
        StdOut.println(tree1);
        StdOut.println(t1.getValidationMessage());

        if (!t1.isTree()) {
            return;
        }

        StdOut.print("Centro(s): ");
        for (int c : t1.getCenters()) {
            StdOut.print(c + " ");
        }
        StdOut.println();

        String code1 = t1.getCanonicalEncoding();

        StdOut.println("Codigo canonico: " + code1);


        StdOut.println();
        StdOut.println("-------------------");
        StdOut.println();


        StdOut.println("ARVORE 2");
        StdOut.println(tree2);
        StdOut.println(t2.getValidationMessage());

        if (!t2.isTree()) {
            return;
        }

        StdOut.print("Centro(s): ");
        for (int c : t2.getCenters()) {
            StdOut.print(c + " ");
        }
        StdOut.println();

        String code2 = t2.getCanonicalEncoding();

        StdOut.println("Codigo canonico: " + code2);


        StdOut.println();
        StdOut.println("===================");

        if (code1.equals(code2)) {
            StdOut.println("VEREDITO: ISOMORFAS");
        } else {
            StdOut.println("VEREDITO: NAO ISOMORFAS");
        }
    }
}